<?php

const DB_HOST	 = "localhost";			
const DB_USER	 = "vinson";	
const DB_PASS	= "vnguyen6";	
const DB_NAME 	= "bcit";		
?>